sampleApp.factory('Nerd', ['$http', function($http) {

	

}]);